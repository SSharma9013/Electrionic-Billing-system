
#include <avr/io.h>
#include<util/delay.h>
#include<avr/interrupt.h>
#include "IncFile1.h"

#define F_CPU 16000000UL
#define unit 7.31
unsigned int balance=0;
unsigned int TotalPulses=0;



uint8_t Readvalue()
{
DDRD=0x00;
PORTD=0xFF;
 MCUCR |= ((1 << ISC00) | (1 << ISC01)); // Rising edge of INT0 will fire the ISR
 GICR |= (1 << INT0); // Enable INT0 interrupt, will call INT0_vect ISR when INT0 fires
 
 sei();      // Enable global interrupts
 return balance;
 
 while(1);      
 }

 ISR(INT0_vect)
 {
	 TotalPulses++; 
	      balance+=TotalPulses*unit;//total balance
		  _delay_ms(2000);
     	  if(TotalPulses>30)//the unit consumption for the month has exceeded
		  {
		  TotalPulses=0;
		  }
	  _delay_ms(2000);
 }
   

	
    