/*
 * IncFile1.h
 *
 * Created: 2/2/2018 10:20:47 AM
 *  Author: MSI
 */ 


#ifndef INCFILE1_H_
#define INCFILE1_H_


uint8_t Readvalue();





#endif /* INCFILE1_H_ */